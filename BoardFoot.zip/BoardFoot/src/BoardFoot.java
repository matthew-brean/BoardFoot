/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-09-16
* Created for: ICS4U
* Daily Assignment: Unit #1-07
* This program calls a procedure to calculate a BoardFoot (volume of wood) 
* given two dimensions and it gives you the width for it to equal 144"^3
*******************************************************************************/

import java.util.Scanner;
import java.util.Random;


public class BoardFoot {

    public static void BoardFootProcedure(double dim1, double dim2) { //basically (length, width)

    	double width;
    	
    	width = (144 / dim1 / dim2) ;
    	
    	System.out.println("The width is: " + width);

    }
	
    
    
public static void main(String[] args)
{
	
	Scanner SCAN= new Scanner(System.in);
	
	System.out.println("First dimension: ");
	double dim1given = SCAN.nextDouble();
	
	System.out.println("Second dimension: ");
	double dim2given = SCAN.nextDouble();
	
	
	BoardFootProcedure(dim1given, dim2given);//call func
 }
}
